-- phpMyAdmin SQL Dump
-- version 4.4.15.9
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 17, 2019 at 10:29 PM
-- Server version: 5.6.37
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `charactor creator`
--

-- --------------------------------------------------------

--
-- Table structure for table `Allies`
--

DROP TABLE IF EXISTS `Allies`;
CREATE TABLE IF NOT EXISTS `Allies` (
  `ID` int(11) NOT NULL,
  `IDPerso1` int(11) NOT NULL,
  `IDPerso2` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Allies`
--

INSERT INTO `Allies` (`ID`, `IDPerso1`, `IDPerso2`) VALUES
(1, 1, 2),
(2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `habiletes`
--

DROP TABLE IF EXISTS `habiletes`;
CREATE TABLE IF NOT EXISTS `habiletes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `ShortDesc` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `habiletes`
--

INSERT INTO `habiletes` (`id`, `name`, `Description`, `ShortDesc`) VALUES
(1, 'Fort', 'Vous avez une force phénoménale! Vous pouvez transporter plus et soulever beaucoup plus que la norme!', 'Vous etes plus fort');

-- --------------------------------------------------------

--
-- Table structure for table `personnage`
--

DROP TABLE IF EXISTS `personnage`;
CREATE TABLE IF NOT EXISTS `personnage` (
  `id` int(11) NOT NULL,
  `Nom` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Habiletes` int(11) NOT NULL,
  `Allies` int(11) NOT NULL,
  `Image` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `personnage`
--

INSERT INTO `personnage` (`id`, `Nom`, `Description`, `Habiletes`, `Allies`, `Image`, `user_id`) VALUES
(1, 'Danger', 'il est bon', 0, 0, 0, 1),
(2, 'patate', 'il est moins bon', 0, 0, 0, 1),
(3, 'gniochon', 'pas bon du tout', 0, 0, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL,
  `title` varchar(191) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `rank` varchar(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `rank`, `username`, `email`, `password`, `created`, `modified`) VALUES
(1, 'admin', 'admin01', 'adminAdmin@admin', '$2y$10$5KNd66M1.5IEQWmBQT1GpOvUozItN77iM6UjimqDn56FZEijeItMm', '2019-10-15 22:46:29', '2019-10-15 22:46:29'),
(2, 'admin', 'DavidP.', 'dvdp26@gmail.com', '$2y$10$vDS9DkTobbcc149ry1feyerz1ZfCmB2HY.Z4XZ2WO/gftXJu9RW.y', '2019-10-15 22:52:08', '2019-10-15 22:52:08'),
(3, 'author', 'Utilisateur', 'utilisateur@fake.com', '$2y$10$4uzMmPtVE3AOTNtKSdCDKObFBSF2IJ8zkcp2LfZCW273qFGtQThku', '2019-10-15 22:53:47', '2019-10-15 22:53:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Allies`
--
ALTER TABLE `Allies`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `habiletes`
--
ALTER TABLE `habiletes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personnage`
--
ALTER TABLE `personnage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Allies`
--
ALTER TABLE `Allies`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `habiletes`
--
ALTER TABLE `habiletes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `personnage`
--
ALTER TABLE `personnage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
